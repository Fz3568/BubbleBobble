SO BASICALLY, THERE'S TWO ADDITIONAL SCENES THAT ARE PRESENT IN THE PROJECT (as of 2024/11/21)

1. Control Configuerer
This one is the scene where control config UI was built.

2. Level Transition Template
This one is a bit more important. It contains a sample level with 2 level transition point (repersented using squres), white one is the starting point, red is the ending point.
The former has a configurable connection already set up. just drag and drop the destination of the transition into the inspector.
The later has a script attatched to it that re-enables plyaer's shooting using a public bool.
